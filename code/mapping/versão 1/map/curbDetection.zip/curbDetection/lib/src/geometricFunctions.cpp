/******************************************************************************/
/*                          UNIVERSIDADE DE SAO PAULO                         */
/*             INSTITUTO DE CIENCIAS MATEMATICAS E DE COMPUTACAO              */
/*                        LABORATORIO DE ROBOTICA MOVEL                       */
/*----------------------------------------------------------------------------*/
/* AUTOR: HEITOR DE FREITAS VIEIRA                           DATA: 23/10/2010 */
/*----------------------------------------------------------------------------*/
/* Para compilar:                                                             */
/* g++ -c -Wall geometricFunctions.cpp -lm                                    */
/*----------------------------------------------------------------------------*/
/* TESTADO COM:                                                               */
/*           - UBUNTU 10.10 (64bits)                                          */
/*----------------------------------------------------------------------------*/
/* DESCRICAO DO PROGRAMA:                                                     */
/*     Possui algumas funções para calculos geométricos.                      */
/******************************************************************************/

 /**
 * @author <b>HEITOR DE FREITAS VIEIRA
 * @date 23/10/2010\n
 * @note
 * TESTADO COM:\n
 *           - UBUNTU 10.10 (64bits)\n
 */

///////////////////////////////////////////////////////////////////////////////
//  BIBLIOTECAS
///////////////////////////////////////////////////////////////////////////////
#include "geometricFunctions.h"

///////////////////////////////////////////////////////////////////////////////
//	drReduzida
///////////////////////////////////////////////////////////////////////////////
/**
 * Calcula a distância entre um ponto e uma reta (Y(x)=ax+b).
 * @param r Equação reduzida da reta.
 * @param x0 Coordenada x do ponto (x,y).
 * @param y0 Coordenada y do ponto (x,y).
 * @return Distância entre o ponto e a reta.
 */
double drReduzida(retaReduzida *r, double x0, double y0){
	retaGeral rg;
	rg = reduzida2geral(r);
	double ret = drGeral(&rg, x0, y0);
	
	return ret;
}

///////////////////////////////////////////////////////////////////////////////
// drGeral
///////////////////////////////////////////////////////////////////////////////
/**
 * Calcula a distância entre um ponto e uma reta (ax+by+c=0)
 * @param r Equação da reta geral da reta.
 * @param x0 Coordenada x do ponto (x,y).
 * @param y0 Coordenada y do ponto (x,y).
 * @return Distância entre ponto e reta.
 */
double drGeral(retaGeral *r, double x0, double y0){
	
	double ret;
	if((r->a != 0) || (r->b != 0)) {
		ret = fabs((r->a * x0) + (r->b * y0) + r->c) / sqrt((r->a*r->a)+(r->b*r->b));
		return ret;
	}
	
	return INFINITY;
 }

///////////////////////////////////////////////////////////////////////////////
// reduzida2geral
///////////////////////////////////////////////////////////////////////////////
/**
 * Converte a equação reduzida da reta em equação geral.
 * @param r Equação da reta reduzida a ser convertida.
 */
retaGeral reduzida2geral(retaReduzida *r){
	retaGeral ret;
	ret.a=-r->a;
	ret.b=1;
	ret.c=-r->b;
	return ret;
}

///////////////////////////////////////////////////////////////////////////////
// geral2reduzida
///////////////////////////////////////////////////////////////////////////////
/**
 * Converte a equação geral da reta em equação reduzida.
 * @param r Equação geral a ser convertida.
 */
retaReduzida geral2reduzida(retaGeral r){
	retaReduzida ret;
	ret.a=(-r.a/r.b);
	ret.b=(-r.c/r.b);
	ret.deltaA=INFINITY;
	ret.deltaB=INFINITY;
	return ret;
}

///////////////////////////////////////////////////////////////////////////////
// dPQ
///////////////////////////////////////////////////////////////////////////////
/**
 * Calcula a distancia entre dois pontos.
 * @param x1 Coordenada x do primeiro ponto.
 * @param y1 Coordenada y do primeiro ponto.
 * @param x2 Coordenada x do segundo ponto.
 * @param y2 Coordenada y do segundo ponto.
 * @return Distancia entre o ponto (x1,y1) e (x2,y2).
 */
double dPQ(double x1, double y1, double x2, double y2){
	double ret;
	ret = sqrt(pow((x1-x2),2) + pow((y1-y2),2));
	return ret;
}

///////////////////////////////////////////////////////////////////////////////
// anguloEntreRetas
///////////////////////////////////////////////////////////////////////////////
/**
 * Calcula o angulo entre duas retas.
 * @param r1 Equação da reta reduzida (Y(x)=ax+b)
 * @param r2 Equação da reta reduzida (Y(x)=ax+b)
 * @return Angulo entre r1 e r2 em radianos.
 */
double anguloEntreRetas(retaReduzida r1, retaReduzida r2){
	
	double ret;
	
	ret = atan(fabs((r2.a - r1.a) / (1+(r2.a * r1.a))));
	
	return ret;
}
