/******************************************************************************/
/*                          UNIVERSIDADE DE SAO PAULO                         */
/*             INSTITUTO DE CIENCIAS MATEMATICAS E DE COMPUTACAO              */
/*                        LABORATORIO DE ROBOTICA MOVEL                       */
/*----------------------------------------------------------------------------*/
/* AUTORE: HEITOR DE FREITAS VIEIRA                         DATA: 19/05/2011  */
/*----------------------------------------------------------------------------*/
/* Para compilar:                                                             */
/*  Veja Makefile                                                             */
/*----------------------------------------------------------------------------*/
/* TESTADO COM:                                                               */
/*           - UBUNTU 10.10 (64bits)                                          */
/*----------------------------------------------------------------------------*/
/* DESCRICAO DO PROGRAMA:                                                     */
/*     Detecta as guias da rua com o auxílio do laser.                        */
/******************************************************************************/

 /**
 * @author <b>HEITOR DE FREITAS VIEIRA
 * @date 19/05/2011\n
 * @note
 * TESTADO COM:\n
 *           - UBUNTU 10.14 (64bits)\n
 */

////////////////////////////////////////////////////////////////////////////////
//  BIBLIOTECAS
////////////////////////////////////////////////////////////////////////////////
#include "curbDetection.h"

/* Guarda as informações das duas guias (0 -> Direita; 1 -> Esquerda ) */
CURB_DATA curbs[2];

/* Guarda as informações do filtro */
FILTER_DATA filter[2];

///////////////////////////////////////////////////////////////////////////////
// cdFindCurbs
///////////////////////////////////////////////////////////////////////////////
/**
 * Detecta as guias em uma única leitura do laser.
 * @param laserData informações do laser provida pelo player.
 * @param curbHeight Altura da guia, em metros. Padrão -> curbHeight = 0.07 (vide CURB_HEIGHT em curbDetection.h)
 */
void cdFindCurbs(playerc_laser_t *laserData, float curbHeight){
	
	/* Verifica se o algoritimo pode ser aplicado ou não */
	if(laserData->scan_count != 361){
		fprintf(stderr, "IMPOSSIVEL DETECTAR GUIAS:\n");
		fprintf(stderr, "Leituras do laser devem ser de 0,5°\n\n");
	}
	else {
    
		/* Guarda o numero de leituras do laser em uma única varredura */
		int numberOfBeans = laserData->scan_count;
		
		/* Para conversão de coordenadas polares em retangulares */
		double x[numberOfBeans], y[numberOfBeans];
		
		/* Buffer de pontos a ser calculado a média */
		double pts[2][3];

		/* Para saber se encontrou a guia ou não */
		bool outOfRange; //Indica se estorou os vetores (x e y) ou não.
		
		int i,j,n = 0;   //Indice dos vetores x e y para detecção da guia
		
		double ch; //variável temporária que armazena a altura da guia calculada.
		
		/* Transforma coordenadas polares em coordenadas cartesianas */
		#pragma omp parallel for schedule(dynamic, 10)
			for(i=0; i < numberOfBeans; i++){
				x[i] = cos(1.570796327 -i*0.008726646) * laserData->scan[i][0];
				y[i] = sin(1.570796327 -i*0.008726646) * laserData->scan[i][0];
			}
		
	/*-----------------------------------------------------------------------*/
	/* PROCURA GUIA DIREITA                                                  */
	/*-----------------------------------------------------------------------*/
		#pragma omp parallel num_threads(2) private(i,j,n,ch,outOfRange, pts) shared(curbs)
		{
			#pragma omp sections nowait
			{
				#pragma omp section
				{
					curbs[RIGHT].found = false;
					outOfRange = false;
					i = (int)((float)numberOfBeans/2.0);  //Começa a leitura no centro do carro
					
					/* Procura pela guia direita */
					while (!curbs[RIGHT].found && !outOfRange){
						
						/* Investiga se pode prosseguir */
						j=0;
						for(n=0; n < 5; n++){
							if(laserData->scan[i-n][0] >= (laserData->max_range-curbHeight)){
								j++;
							}
						}
						/* Se os proximos 5 feixes de laser forem imprecisos, sai do laço */
						if(j >= 5){
							curbs[RIGHT].curb.x = 0;
							curbs[RIGHT].curb.y = 0;
							curbs[RIGHT].found = false;
							break;
						}
						
						/* Calcula o primeiro ponto da reta suporte */
						n=0;
						for(j=0; j<3; j++){
							if(laserData->scan[i-j][0] < (laserData->max_range-curbHeight)){
								pts[0][n] = x[i-j];
								pts[1][n] = y[i-j];
								n++;
							}
						}
						if(n == 1){
							curbs[RIGHT].pt1.x = pts[0][0];
							curbs[RIGHT].pt1.y = pts[1][0];
						}
						else if(n > 1){
							curbs[RIGHT].pt1.x=harmonicMean(n,pts[0]);
							curbs[RIGHT].pt1.y=harmonicMean(n,pts[1]);
						}
						/* Se não foi possível determinar o primeiro ponto da reta suporte, reinicia o laço */
						else {
							i--;
							outOfRange = (i > 13) ? false : true;
							continue;
						}
						
						/* Calcula o segundo ponto da reta suporte */
						n=0;
						for(j=0; j<3; j++){
							if(laserData->scan[i-j-7][0] < (laserData->max_range-curbHeight)){
								pts[0][n] = x[i-j-7];
								pts[1][n] = y[i-j-7];
								n++;
							}
						}
						if(n == 1){
							curbs[RIGHT].pt2.x = pts[0][0];
							curbs[RIGHT].pt2.y = pts[1][0];
						}
						else if(n > 1){
							curbs[RIGHT].pt2.x=harmonicMean(n,pts[0]);
							curbs[RIGHT].pt2.y=harmonicMean(n,pts[1]);
						}
						/* Se não foi possível determinar o segundo ponto da reta suporte, reinicia o laço */
						else {
							i--;
							outOfRange = (i > 13) ? false : true;
							continue;
						}
						
						/* Sai de condição bizarra */
						if(curbs[RIGHT].pt2.y < curbs[RIGHT].pt1.y){
							curbs[RIGHT].curb.x = 0;
							curbs[RIGHT].curb.y = 0;
							curbs[RIGHT].found = false;
							break;
						}
						
						/* Verifica se os pontos da reta suporte estão próximos */
						if(dPQ(curbs[RIGHT].pt1.x, curbs[RIGHT].pt1.y, curbs[RIGHT].pt2.x, curbs[RIGHT].pt2.y) > (11*curbHeight)){
							curbs[RIGHT].curb.x = 0;
							curbs[RIGHT].curb.y = 0;
							curbs[RIGHT].found = false;
							break;
						}
						
						/* Calcula o o ponto da guia usando média harmonica */
						n=0;
						for(j=0; j<3; j++){
							if(laserData->scan[i-j-11][0] < (laserData->max_range-curbHeight)){
								pts[0][n] = x[i-j-11];
								pts[1][n] = y[i-j-11];
								n++;
							}
						}
						/* Se achou somente um feixe de laser confiável */
						if(n == 1){
							curbs[RIGHT].curb.x = pts[0][0];
							curbs[RIGHT].curb.y = pts[1][0];
						}
						/* Se achou mais de um feixe de laser confiável */
						else if(n > 1){
							curbs[RIGHT].curb.x=harmonicMean(n,pts[0]);
							curbs[RIGHT].curb.y=harmonicMean(n,pts[1]);
						}
						/* Caso não tenha encontrado uma suposta guia */
						else {
							i--;
							outOfRange = (i > 13) ? false : true;
							continue;
						}
						
						/* Faz a especulação de ter encontrado a guia direita */
						curbs[RIGHT].found = true;

						/* Calcula os coeficientes equção geral da reta (ax+by+c=0) suporte direita */
						curbs[RIGHT].suportLine.a=curbs[RIGHT].pt1.y - curbs[RIGHT].pt2.y;
						curbs[RIGHT].suportLine.b=curbs[RIGHT].pt2.x - curbs[RIGHT].pt1.x;
						curbs[RIGHT].suportLine.c=(curbs[RIGHT].pt1.x*curbs[RIGHT].pt2.y) - (curbs[RIGHT].pt1.y*curbs[RIGHT].pt2.x);
						
						/* Calcula a distancia entre a reta suporte e o ponto da guia */
						ch = drGeral(&curbs[RIGHT].suportLine, curbs[RIGHT].curb.x, curbs[RIGHT].curb.y);
						
						/* Se a distancia entre a suposta guia e a reta suporte for menor que curbHeight */
						if (ch < (curbHeight)){
							curbs[RIGHT].found = false;
						}
							
						/* Se a distancia entre a suposta guia for maior que 2*curbHeight */
						else if (ch > (2*curbHeight)){
							curbs[RIGHT].found = false;
						}
						/* Descarta situação onde não encontrou a reta suporte apropriada ou guia aproriada */
						else if((curbs[RIGHT].pt1.x == 0) || (curbs[RIGHT].pt2.x == 0) || (curbs[RIGHT].curb.x == 0)){
							curbs[RIGHT].found = false;
						}
						
						i--;
						outOfRange = (i > 13) ? false : true;
					}
					
					/* Para indicar que não achou a guia direita */
					if(!curbs[RIGHT].found){
						curbs[RIGHT].curb.x = 0;
						curbs[RIGHT].curb.y = 0;
					}
					
					curbs[RIGHT].curbHeight = curbHeight;
				}
				
	/*-----------------------------------------------------------------------*/
	/* PROCURA GUIA ESQUERDA                                                 */
	/*-----------------------------------------------------------------------*/
				#pragma omp section
				{	
					curbs[LEFT].found = false;
					outOfRange = false;
					i = (int)((float)numberOfBeans/2.0);  //Começa a leitura no centro do carro
							
					/* Procura pela guia esquerda */
					while(!curbs[LEFT].found && !outOfRange) {
						
						/* Investiga se pode prosseguir */
						j=0;
						for(n=0; n < 5; n++){
							if(laserData->scan[i+n][0] >= (laserData->max_range-curbHeight)){
								j++;
							}
						}
						/* Se os proximos 5 feixes de laser forem imprecisos, sai do laço */
						if(j >= 5){
							curbs[LEFT].curb.x = 0;
							curbs[LEFT].curb.y = 0;
							curbs[LEFT].found = false;
							break;
						}
						
						/* Calcula o primeiro ponto da reta suporte */
						n=0;
						for(j=0; j<3; j++){
							if(laserData->scan[i+j][0] < (laserData->max_range-curbHeight)){
								pts[0][n] = x[i+j];
								pts[1][n] = y[i+j];
								n++;
							}
						}
						if(n == 1){
							curbs[LEFT].pt1.x = pts[0][0];
							curbs[LEFT].pt1.y = pts[1][0];
						}
						else if(n > 1){
							curbs[LEFT].pt1.x=harmonicMean(n,pts[0]);
							curbs[LEFT].pt1.y=harmonicMean(n,pts[1]);
						}
						/* Se não foi possível determinar o primeiro ponto da reta suporte, reinicia o laço */  
						else {
							i++;
							outOfRange = (i < (numberOfBeans-13)) ? false : true;
							continue;
						}
						
						/* Calcula o segundo ponto da reta suporte */
						n=0;
						for(j=0; j<3; j++){
							if(laserData->scan[i+j+7][0] < (laserData->max_range-curbHeight)){
								pts[0][n] = x[i+j+7];
								pts[1][n] = y[i+j+7];
								n++;
							}
						}
						if(n == 1){
							curbs[LEFT].pt2.x = pts[0][0];
							curbs[LEFT].pt2.y = pts[1][0];
						}
						else if(n > 1){
							curbs[LEFT].pt2.x=harmonicMean(n,pts[0]);
							curbs[LEFT].pt2.y=harmonicMean(n,pts[1]);
						}
						/* Se não foi possível determinar o segundo ponto da reta suporte, reinicia o laço */   
						else {
							i++;
							outOfRange = (i < (numberOfBeans-13)) ? false : true;
							continue;
						}
						
						/* Sai de condição bizarra */
						if(curbs[LEFT].pt1.y < curbs[LEFT].pt2.y){
							curbs[LEFT].curb.x = 0;
							curbs[LEFT].curb.y = 0;
							curbs[LEFT].found = false;
							break;
						}
						
						/* Verifica se os pontos da reta suporte estão próximos */
						if(dPQ(curbs[LEFT].pt1.x, curbs[LEFT].pt1.y, curbs[LEFT].pt2.x, curbs[LEFT].pt2.y) > (15*curbHeight)){
							curbs[LEFT].curb.x = 0;
							curbs[LEFT].curb.y = 0;
							curbs[LEFT].found = false;
							break;
						}
						
						/* Calcula o o ponto da guia usando média harmonica */
						n=0;
						for(j=0; j<3; j++){
							if(laserData->scan[i+j+11][0] < (laserData->max_range-curbHeight)){
								pts[0][n] = x[i+j+11];
								pts[1][n] = y[i+j+11];
								n++;
							}
						}
						if(n == 1){
							curbs[LEFT].curb.x = pts[0][0];
							curbs[LEFT].curb.y = pts[1][0];
						}
						else if(n > 1){
							curbs[LEFT].curb.x=harmonicMean(n,pts[0]);
							curbs[LEFT].curb.y=harmonicMean(n,pts[1]);
						}
						/* Se não encontrou uma suposta guia, reinicia o laço */    
						else {
							i++;
							outOfRange = (i < (numberOfBeans-13)) ? false : true;
							continue;
						}
						
						/* Faz a especulação de ter encontrado a guia esquerda */
						curbs[LEFT].found = true;

						/* Calcula os coeficientes equção geral da reta (ax+by+c=0) suporte esquerda */
						curbs[LEFT].suportLine.a=curbs[LEFT].pt1.y - curbs[LEFT].pt2.y;
						curbs[LEFT].suportLine.b=curbs[LEFT].pt2.x - curbs[LEFT].pt1.x;
						curbs[LEFT].suportLine.c=(curbs[LEFT].pt1.x*curbs[LEFT].pt2.y) - (curbs[LEFT].pt1.y*curbs[LEFT].pt2.x);
						
						/* Calcula a distancia entre a reta suporte e o ponto formado pela */
						/* média harmonica dos proximos 3 pontos */
						ch = drGeral(&curbs[LEFT].suportLine, curbs[LEFT].curb.x, curbs[LEFT].curb.y);
						
						/* Se a distancia entre a suposta guia e a reta suporte for menor que curbHeight */
						if (ch < (curbHeight*1.057)){
							curbs[LEFT].found = false;
						}
							
						/* Se a distancia entre a suposta guia for maior que 3*curbHeight */
						else if (ch > (2*curbHeight)){
							curbs[LEFT].found = false;
						}
						/* Descarta situação onde não encontrou a reta suporte apropriada ou guia aproriada */
						else if((curbs[LEFT].pt1.x == 0) || (curbs[LEFT].pt2.x == 0) || (curbs[LEFT].curb.x == 0)){
							curbs[LEFT].found = false;
						}
						
						i++;
						outOfRange = (i < (numberOfBeans-13)) ? false : true;
					}
					
					/* Para indicar que não achou a guia esquerda */
					if(!curbs[LEFT].found){     
						curbs[LEFT].curb.x = 0;
						curbs[LEFT].curb.y = 0;
					}
					curbs[LEFT].curbHeight = curbHeight;
				}
			}
		}
	}
}

///////////////////////////////////////////////////////////////////////////////
// cdGetCurb
///////////////////////////////////////////////////////////////////////////////
/**
 * Retorna as coordenadas (x,y) da guia.
 * @param curbType Tipo de guia. curbType = 0 -> guia direita; curbType = 1 -> guia esquerda.
 * @return coordenadas (x,y) da guia. (0,0) se a guia não foi detectada ou se o tipo de guia é incorreto.
 */
ponto2D cdGetCurb(int curbType){
    
    /* Variável de retorno */
    ponto2D ret;
    ret.x = 0;
    ret.y = 0;
    
    switch (curbType) {
        /* Guia direita */
        case RIGHT : {
            ret = curbs[RIGHT].curb;
        } break;
        
        /* Guia esquerda */
        case LEFT : {
            ret = curbs[LEFT].curb;
        } break;
        
        /* Guia desconhecida */
        default : {
            fprintf(stderr, "Unknown curb type! cdGetCurb(%d). curbType must be RIGHT:%d or LEFT:%d.\n",curbType, RIGHT, LEFT);
        } break;
    }
    return ret;
}

///////////////////////////////////////////////////////////////////////////////
// getCurbDistance
///////////////////////////////////////////////////////////////////////////////
/**
 * Retorna a distância entre o centro do laser e a guia.
 * @param curbType Tipo de guia. curbType = 0 -> guia direita; curbType = 1 -> guia esquerda.
 * @return distância entre o centro do laser e a guia.
 */
double cdGetCurbDistance(int curbType){
    
    /* Variável de retorno */
    double ret = 0.0;
    
    switch (curbType) {
        
        /* Guia direita */
        case RIGHT : {
            ret = fabs(curbs[RIGHT].curb.y);
        } break;
        
        /* Guia esquerda */
        case LEFT : {
            ret = fabs(curbs[LEFT].curb.y);
        } break;
        
        /* Guia desconhecida */
        default : {
			fprintf(stderr, "Unknown curb type! cdGetCurbDistance(%d). curbType must be RIGHT:%d or LEFT:%d.\n",curbType, RIGHT, LEFT);
        } break;
    }   
    return ret;
}

///////////////////////////////////////////////////////////////////////////////
// getRightSuportLine
///////////////////////////////////////////////////////////////////////////////
/**
 * Retorna a equação geral da reta suporte usada para detectar a guia.
 * @param curbType Tipo de guia. curbType = 0 -> guia direita; curbType = 1 -> guia esquerda.
 * @return Equação geral da reta suporte usada para detectar a guia.
 */
retaGeral cdGetSuportLine(int curbType){
    
    /* Variável de retorno */
    retaGeral ret;
    
    ret.a = 0.0;
    ret.b = 0.0;
    ret.c = 0.0;
    
    switch (curbType) {
        /* Guia direita */
        case RIGHT : {
            ret = curbs[RIGHT].suportLine;
        } break;
        
        /* Guia esquerda */
        case LEFT : {
            ret = curbs[LEFT].suportLine;
        } break;
        
        /* Guia desconhecida */
        default : {
			fprintf(stderr, "Unknown curb type! cdGetSuportLine(%d). curbType must be RIGHT:%d or LEFT:%d.\n",curbType, RIGHT, LEFT);
        } break;
    }   
    return ret;
}

///////////////////////////////////////////////////////////////////////////////
// cdGetPt1
///////////////////////////////////////////////////////////////////////////////
/**
 * Retorna o primeiro ponto calculado da reta suporte.
 * @param curbType Tipo de guia. curbType = 0 -> guia direita; curbType = 1 -> guia esquerda.
 * @return Primeiro ponto calculado da reta suporte.
 */
ponto2D cdGetPt1(int curbType){
    /* Variável de retorno */
    ponto2D ret;
    ret.x = 0;
    ret.y = 0;
    
    switch (curbType) {
        /* Guia direita */
        case RIGHT : {
            ret = curbs[RIGHT].pt1;
        } break;
        
        /* Guia esquerda */
        case LEFT : {
            ret = curbs[LEFT].pt1;
        } break;
        
        /* Guia desconhecida */
        default : {
			fprintf(stderr, "Unknown curb type! cdGetPt1(%d). curbType must be RIGHT:%d or LEFT:%d.\n",curbType, RIGHT, LEFT);
        } break;
    }
    return ret;
}

///////////////////////////////////////////////////////////////////////////////
// cdGetPt2
///////////////////////////////////////////////////////////////////////////////
/**
 * Retorna o segundo ponto calculado da reta suporte direita.
 * @param curbType Tipo de guia. curbType = 0 -> guia direita; curbType = 1 -> guia esquerda.
 * @return Segundo ponto calculado da reta suporte direita.
 */
ponto2D cdGetPt2(int curbType){
    /* Variável de retorno */
    ponto2D ret;
    ret.x = 0;
    ret.y = 0;
    
    switch (curbType) {
        /* Guia direita */
        case RIGHT : {
            ret = curbs[RIGHT].pt2;
        } break;
        
        /* Guia esquerda */
        case LEFT : {
            ret = curbs[LEFT].pt2;
        } break;
        
        /* Guia desconhecida */
        default : {
			fprintf(stderr, "Unknown curb type! cdGetPt2(%d). curbType must be RIGHT:%d or LEFT:%d.\n",curbType, RIGHT, LEFT);
        } break;
    }
    return ret;
}

///////////////////////////////////////////////////////////////////////////////
//  cdFoundCurb
///////////////////////////////////////////////////////////////////////////////
/**
 * Mostra o resultado da última análise das guias.
 * @param curbType Tipo de guia. curbType = 0 -> guia direita; curbType = 1 -> guia esquerda.
 * @return Verdadeiro se encontrou a guia ou falso caso contrário.
 */
bool cdFoundCurb(int curbType){
    /* Variável de retorno */
    bool ret;
    
    ret = false;
    
    switch (curbType) {
        /* Guia direita */
        case RIGHT : {
            ret = curbs[RIGHT].found;
        } break;
        
        /* Guia esquerda */
        case LEFT : {
            ret = curbs[LEFT].found;
        } break;
        
        /* Guia desconhecida */
        default : {
			fprintf(stderr, "Unknown curb type! cdFoundCurb(%d). curbType must be RIGHT:%d or LEFT:%d.\n",curbType, RIGHT, LEFT);
        } break;
    }
    return ret;
}

///////////////////////////////////////////////////////////////////////////////
// cdMeanFilter
///////////////////////////////////////////////////////////////////////////////
/**
 * Aplica o filtro de média harmônica sobre as leituras das guias anteriores.
 */
void cdMeanFilter(){
    
    /* Acumula no buffer as três primeiras leituras da guia direita */
    if(filter[RIGHT].curbID < 3){
        filter[RIGHT].distances[filter[RIGHT].curbID++] = cdGetCurbDistance(RIGHT);
    }   
    /* Se há mais de três leituras acumuladas, processa o filtro */
    else {
        /* Desloca os registros anteriores de distâncias */
        filter[RIGHT].distances[0] = filter[RIGHT].distances[1];
        filter[RIGHT].distances[1] = filter[RIGHT].distances[2];
        filter[RIGHT].distances[2] = cdGetCurbDistance(RIGHT);
        
        /* Calcula a média entre as três leituras */
        filter[RIGHT].mean = arithmeticMean(3, filter[RIGHT].distances[0], filter[RIGHT].distances[1], filter[RIGHT].distances[2]);
        
        /* Se a distância acumulada for menor que 50cm */
        if(filter[RIGHT].mean < 0.5) {
            filter[RIGHT].mean = 0;
        }
        
        /* Atualiza o dado */
        filter[RIGHT].distances[2] = filter[RIGHT].mean;
    }
    
    /* Acumula no buffer as três primeiras leituras da guia esquerda */
    if(filter[LEFT].curbID < 3){
        filter[LEFT].distances[filter[LEFT].curbID++] = cdGetCurbDistance(LEFT);
    }   
    /* Se há mais de três leituras acumuladas, processa o filtro */
    else {
        /* Desloca os registros anteriores de distâncias */
        filter[LEFT].distances[0] = filter[LEFT].distances[1];
        filter[LEFT].distances[1] = filter[LEFT].distances[2];
        filter[LEFT].distances[2] = cdGetCurbDistance(LEFT);
        
        /* Calcula a média entre as três leituras */
        filter[LEFT].mean = arithmeticMean(3, filter[LEFT].distances[0], filter[LEFT].distances[1], filter[LEFT].distances[2]);
        
        /* Se a distância acumulada for menor que 50cm */
        if(filter[LEFT].mean < 0.5) {
            filter[LEFT].mean = 0;
        }
        
        /* Atualiza o dado */
        filter[LEFT].distances[2] = filter[LEFT].mean;
    }
}

///////////////////////////////////////////////////////////////////////////////
// cdGetRightMeanDistance
///////////////////////////////////////////////////////////////////////////////
/**
 * Retorna a média das últimas três distâncias medidas do lado direito.
 * @param curbType Tipo de guia. curbType = 0 -> guia direita; curbType = 1 -> guia esquerda.
 * @return Média das últimas três distâncias medidas do lado direito.
 */
double cdGetMeanDistance(int curbType){
    /* Variável de retorno */
    double ret;
    
    ret = 0.0;
    
    switch (curbType) {
        /* Guia direita */
        case RIGHT : {
            ret = filter[RIGHT].mean;
        } break;
        
        /* Guia esquerda */
        case LEFT : {
            ret = filter[LEFT].mean;
        } break;
        
        /* Guia desconhecida */
        default : {
			fprintf(stderr, "Unknown curb type! cdMeanDistance(%d). curbType must be RIGHT:%d or LEFT:%d.\n",curbType, RIGHT, LEFT);
        } break;
    }
    return ret;
}

///////////////////////////////////////////////////////////////////////////////
// cdGetCurbData
///////////////////////////////////////////////////////////////////////////////
/**
 * Retorna os dados de uma guia.
 * @param curbType Tipo de guia. curbType = 0 -> guia direita; curbType = 1 -> guia esquerda.
 * @return Dados de uma guia.
 */
CURB_DATA cdGetCurbData(int curbType){
    CURB_DATA ret;
    
    switch (curbType) {
        /* Caso seja a guia direita (curbType = 0) */
        case RIGHT : {
            ret = curbs[RIGHT]; 
        } break;

        /* Caso seja a guia esquerda (curbType = 1) */
        case LEFT : {
            ret = curbs[LEFT];
        } break;

        /* Tipo inválido de guia */
        default: { 
			fprintf(stderr, "Unknown curb type! cdGetCurbData(%d). curbType must be RIGHT:%d or LEFT:%d.\n",curbType, RIGHT, LEFT);
        } break;
    }
    return ret;
}
 
///////////////////////////////////////////////////////////////////////////////
// cdGetFilterData
///////////////////////////////////////////////////////////////////////////////
/**
 * Retorna os dados do filtro de uma guia.
 * @param curbType Tipo de guia. curbType = 0 -> guia direita; curbType = 1 -> guia esquerda.
 * @return Dados do filtro de uma guia.
 */
FILTER_DATA cdGetFilterData(int curbType){
    FILTER_DATA ret;
    
    switch (curbType) {
        /* Caso seja a guia direita (curbType = 0) */
        case RIGHT : { 
            ret = filter[RIGHT]; 
        } break;

        /* Caso seja a guia esquerda (curbType = 1) */
        case LEFT :  { 
            ret = filter[LEFT];         
        } break;

        default: {
			fprintf(stderr, "Unknown curb type! cdGetFilterData(%d). curbType must be RIGHT:%d or LEFT:%d.\n",curbType, RIGHT, LEFT);
        } break;
    }
    return ret;
}

///////////////////////////////////////////////////////////////////////////////
//  cdInit
///////////////////////////////////////////////////////////////////////////////
/**
 * Inicia as variáveis do ambiente.
 */
void cdInit(){
    filter[RIGHT].curbID = 0;
    filter[LEFT].curbID = 0;
    filter[RIGHT].mean = 0;
    filter[LEFT].mean = 0;
}

///////////////////////////////////////////////////////////////////////////////
// cdGetDistance
///////////////////////////////////////////////////////////////////////////////
/**
 * Retorna a distancia entre a guia e o laser.
 * @param curbType Tipo de guia. curbType = 0 -> guia direita; curbType = 1 -> guia esquerda.
 * @return Distancia entre a guia e o centro do laser.
 */
double cdGetDistance(int curbType){
    /* Retorno */
    double ret = 0.0;
    
    switch (curbType){
        /* Se for guia direita (curbType = 0) */
        case RIGHT : {
            ret = dPQ(curbs[LEFT].curb.x, curbs[LEFT].curb.y, 0, 0);
        } break;
        
        /* Se for guia esquerda (curbType = 1) */
        case LEFT : {
            ret = dPQ(curbs[LEFT].curb.x, curbs[LEFT].curb.y, 0, 0);
        } break;
        
        /* Guia desconhecida */
        default : {
			fprintf(stderr, "Unknown curb type! cdGetDistance(%d). curbType must be RIGHT:%d or LEFT:%d.\n",curbType, RIGHT, LEFT);
        } break;    
    }
    return ret;
}

///////////////////////////////////////////////////////////////////////////////
// cdGetAngle
///////////////////////////////////////////////////////////////////////////////
/**
 * Retorna o angulo entre o centro do laser e o feixe laser.
 * @param curbType Tipo de guia. curbType = 0 -> guia direita; curbType = 1 -> guia esquerda.
 * @return Angulo (em radianos) entre o centro do laser e o feixe laser.
 */
double cdGetAngle(int curbType){
    
    /* Retorno */
    double ret = 0.0;
    
    switch (curbType){
        /* Se for guia direita */
        case RIGHT :
        case LEFT  : {
            ret = asin (cdGetCurbDistance(curbType) / cdGetDistance(curbType));
        } break;        
        
        /* Guia desconhecida */
        default : {
			fprintf(stderr, "Unknown curb type! cdGetAngle(%d). curbType must be RIGHT:%d or LEFT:%d.\n",curbType, RIGHT, LEFT);
        } break;
    }
    return ret;
}
