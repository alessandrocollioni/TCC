/******************************************************************************/
/*                          UNIVERSIDADE DE SAO PAULO                         */
/*             INSTITUTO DE CIENCIAS MATEMATICAS E DE COMPUTACAO              */
/*                        LABORATORIO DE ROBOTICA MOVEL                       */
/*----------------------------------------------------------------------------*/
/* AUTORES:   HEITOR DE FREITAS VIEIRA                       DATA: 23/10/2010 */
/*----------------------------------------------------------------------------*/
/* Para compilar:                                                             */
/* g++ -c -Wall means.cpp -lm                                                 */
/*----------------------------------------------------------------------------*/
/* TESTADO COM:                                                               */
/*           - UBUNTU 10.10 (64bits)                                          */
/*----------------------------------------------------------------------------*/
/* DESCRICAO DO PROGRAMA:                                                     */
/*     Possui algumas funções para calcular médias.                           */
/******************************************************************************/

 /**
 * @author <b>HEITOR DE FREITAS VIEIRA
 * @date 23/10/2010\n
 * @note
 * TESTADO COM:\n
 *           - UBUNTU 10.10 (64bits)\n
 */
////////////////////////////////////////////////////////////////////////////////
//  BIBLIOTECAS
////////////////////////////////////////////////////////////////////////////////
#include "means.h"

////////////////////////////////////////////////////////////////////////////////
//	CALCULA A MEDIA HARMONICA                             
////////////////////////////////////////////////////////////////////////////////
/**
 * Calcula a média harmonica entre "num" valores.
 * @param num Numero de entradas.
 * @return Média harmonica.
 */
double harmonicMean(int num, ...){
	va_list arguments;
	int i;
	double sum = 0;
	double tmp;

	va_start ( arguments, num );
	for (i = 0; i < num; i++){
		tmp = (double)va_arg (arguments, double); 
		if(tmp != 0){
			sum += (1/tmp);
		}
		else {
			sum +=10000000;
		}
	} 
	va_end ( arguments );
	
	if (sum != 0){
		return ((double)num/sum);
	}
	else {
		return INFINITY;  //Se ocorrer erro
	}
}

///////////////////////////////////////////////////////////////////////////////
// CALCULA A MEDIA HARMONICA
///////////////////////////////////////////////////////////////////////////////
/**
 * Calcula a média harmonica.
 * @param n Numero de entradas.
 * @param v Vetor com os valores a ser calculado.
 * @return Média harmonica.
 */
double harmonicMean(int n, double *v){
	int i;
	double ret = 0;
	double sum = 0;
	for(i=0; i < n; i++){
		if(v[i] != 0){
			sum += 1/v[i];
		}
		else {
			sum += 10000000;
		}
	}
	
	if(sum != 0){
		ret = ((double)n)/sum;
	}
	
	return ret;
}

///////////////////////////////////////////////////////////////////////////////
// CALCULA A MEDIA ARITMETICA
///////////////////////////////////////////////////////////////////////////////
/**
 * Calcula a média aritmética entre "num" valores.
 * @param num Numero de entradas.
 * @return Média aritmética.
 */
double arithmeticMean(int num, ...){
	va_list arguments;
	int i;
	double sum = 0;
	double tmp = (double)num;

	va_start ( arguments, num );
	for (i = 0; i < num; i++){
		sum += (double)va_arg (arguments, double); 
	} 
	va_end ( arguments );
	
	return (sum/tmp);
}


///////////////////////////////////////////////////////////////////////////////
//  CALCULA A MEDIA PONDERADA
///////////////////////////////////////////////////////////////////////////////
/**
 * Calcula a média ponderada. Ex: weightedMean(4, valor1, peso1, valor2, peso2)
 * @param num Numero de entradas.
 * @return Média ponderada.
 */
double weightedMean(int num, ...){
	va_list arguments;
	int i, index;
	double weights[(int)((float)num/2)];
	double vals[(int)((float)num/2)];
	double sum[2]  = {0 ,0};
	double tmp;

	index = 0;

	va_start ( arguments, num );
	for (i = 0; i < num; i++){
		tmp = (double)va_arg (arguments, double);
		//printf("TMP[%d]: %.3lf\n", i, tmp);
		
		/* Pega os valores */
		if((i%2) == 0){
			vals[index] = tmp;
		}
		/* Pega os pesos */
		else {
			weights[index++] = tmp;
		}
	}
	va_end ( arguments );
	
	/* Calcula a média ponderada */
	for(i = 0; i < index; i++){
		sum[0] += vals[i]*weights[i];
		sum[1] += weights[i];
	}
	
	if(sum[1] != 0){
		return (sum[0]/sum[1]);
	}
	
	return 0;
}
