/*
 * shared.h
 *
 *  Created on: 24/08/2010
 *      Author: leandro
 */

#ifndef SHARED_H_
#define SHARED_H_

/*//////////////////////////////////////////////////
 * Define shared structures
 *////////////////////////////////////////////////*/
typedef struct {
    int x, y, z;
} Point3D_t;

typedef struct {
    int x, y;
} Point2D_t;

typedef struct {
    int x, y;
    double theta;
} Pose2D_t;

typedef struct {
    int x, y, z;
    double rol, pitch, yaw;
} Pose3D_t;

/**
 * Struct para armazenar a equação reduzida da reta (Y(x)=ax+b)
 */
typedef struct {
    float a;       //Coeficiente "a" da equação reduzida da reta (Y(x)=ax + b).
    float b;       //Coeficiente "b" da equação reduzida de reta (Y(x)=ax + b).
    float deltaA;  //Desvio de a.
    float deltaB;  //Desvio de b.
} retaReduzida;

/**
 * Struct para armazenar a equação geral da reta (ax+by+c=0)
 */
typedef struct {
    float a;    //Coeficiente "a" da equação geral da reta (ax+by+c=0)
    float b;    //Coeficiente "b" da equação geral da reta (ax+by+c=0)
    float c;    //Coeficiente "c" da equação geral da reta (ax+by+c=0)
} retaGeral;

/**
 * Struct para armazenar ponto 3D.
 */
typedef struct {    
    float x;    //Coordenada x do ponto (x,y,z).
    float y;    //Coordenada y do ponto (x,y,z).
    float z;    //Coordenada z do ponto (x,y,z).
} ponto3D;

/**
 * Struct para armazenar ponto 2D.
 */
typedef struct {    
    float x;    //Coordenada x do ponto (x,y,z).
    float y;    //Coordenada y do ponto (x,y,z).
} ponto2D;

#endif /* SHARED_H_ */
