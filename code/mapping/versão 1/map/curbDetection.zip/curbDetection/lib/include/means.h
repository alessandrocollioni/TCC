#ifndef MEANS_H_
#define MEANS_H_

#include <cstdarg>
#include <cmath>
#include <cstdlib>

double harmonicMean(int num, ...);
double harmonicMean(int num, double *v);
double arithmeticMean(int num, ...);
double weightedMean(int num, ...);
#endif
