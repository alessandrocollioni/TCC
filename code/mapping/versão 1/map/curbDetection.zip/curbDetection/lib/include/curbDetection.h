/******************************************************************************/
/*                          UNIVERSIDADE DE SAO PAULO                         */
/*             INSTITUTO DE CIENCIAS MATEMATICAS E DE COMPUTACAO              */
/*                        LABORATORIO DE ROBOTICA MOVEL                       */
/*----------------------------------------------------------------------------*/
/* AUTOR: HEITOR DE FREITAS VIEIRA                           DATA: 23/10/2010 */
/*----------------------------------------------------------------------------*/
/* Para compilar:                                                             */
/* TODO: Colocar comandos de compilação.                                      */
/*----------------------------------------------------------------------------*/
/* TESTADO COM:                                                               */
/*           - UBUNTU 10.10 (64bits)                                          */
/*----------------------------------------------------------------------------*/
/* DESCRICAO DO PROGRAMA:                                                     */
/*     Detecta a guia da rua com o auxílio do laser.                          */
/******************************************************************************/

 /**
 * @author <b>HEITOR DE FREITAS VIEIRA
 * @date 23/10/2010\n
 * @note
 * TESTADO COM:\n
 *           - UBUNTU 10.10 (64bits)\n
 */
#ifndef __CURBS__H__
#define __CURBS__H__

#include <cstdlib>
#include <cmath>
#include <cstdio>
#include <libplayerc/playerc.h>
#include "shared.h"
#include "means.h"
#include "geometricFunctions.h"

#define RIGHT 0
#define LEFT 1

/**
 * Define curb height. In meters.
 */
#ifndef _CURB_HEIGHT
    #define CURB_HEIGHT 0.07
#endif

/**
 * Guarda infrmações dos dados internos.
 */
typedef struct {
    retaGeral suportLine;   //Reta suporte
    ponto2D curb;           //Ponto que representa a guia
    bool found;             //Se encontrou a guia ou não
    ponto2D pt1, pt2;       //Primeiro e segundo ponto calculado da reta suporte
    float curbHeight;       //Altura da guia
} CURB_DATA;

typedef struct {
    int curbID;   
    float distances[3];
    float mean;
} FILTER_DATA;

void cdFindCurbs(playerc_laser_t *laserData, float curbHeight = CURB_HEIGHT);
ponto2D cdGetCurb(int curbType);
double cdGetCurbDistance(int curbType);
retaGeral cdGetSuportLine(int curbType);
ponto2D cdGetPt1(int curbType);
ponto2D cdGetPt2(int curbType);
bool cdFoundCurb(int curbType);
void cdMeanFilter();
double cdGetMeanDistance(int curbType);
CURB_DATA cdGetCurbData(int curbType);
FILTER_DATA cdGetFilterData(int curbType);
void cdInit();
double cdGetDistance(int curbType);
double cdGetAngle(int curbType);
#endif
