#ifndef GEOMETRICFUNCTIONS_H_
#define GEOMETRICFUNCTIONS_H_

#define PI 3.14159265

#include <cmath>
#include "shared.h"

double dPQ(double x1, double y1, double x2, double y2);
double drReduzida(retaReduzida *r, double x0, double y0);
double drGeral(retaGeral *r, double x0, double y0);
retaGeral reduzida2geral(retaReduzida *r);
retaReduzida geral2reduzida(retaGeral r);
double dPQ(double x1, double y1, double x2, double y2);
double anguloEntreRetas(retaReduzida r1, retaReduzida r2);
#endif
