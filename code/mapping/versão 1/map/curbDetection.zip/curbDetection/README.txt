********************************************************************************
*                      DETECÇÃO DE GUIAS COM LASER                             *
********************************************************************************

Ver exeplos de uso em "samples"

--------------------------------------------------------------------------------
Detecção de guia sem filtro:
    Não normaliza as leituras.
    
--------------------------------------------------------------------------------
Detecção de guia com filtro:
    Faz uma média entre as três ultimas leituras de guia. Útil para suavisar variações
bruscas. Com o uso do filtro é necessário esperar três leituras do laser para poder
usar os dados.
